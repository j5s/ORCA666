# EVA
# fully undetectable injector
## Update on Monday, July 12 : USE [EVA2](https://github.com/ORCA666/EVA2) INSTEAD .
*************************************************************************************

# [[+] antiscan.me](https://antiscan.me/scan/new/result?id=2COeiu0BcRmz)
![antiscanme](https://user-images.githubusercontent.com/66519611/123218820-d9f80f00-d4d4-11eb-9135-c2bfe861162e.png)

*************************************************************************************

# YOUR MOM IS A -BITCH- IF YOU UPLOADED THIS TO ANY WEBSITE OTHER THAN  `antiscan.me`
# READ THE [UPDATE](https://github.com/ORCA666/EVA/blob/main/UPDATE.md)
*************************************************************************************


# REQUIREMENTS:
* visual studio 2019 [ it may work with visual studio 2017 ]
* cobalt strike [ take a look at my repo `cobalt-wipe` ]
* python2 for the encoder

*************************************************************************************

# USAGE:
* create your shellcode (x64 `x86 wont work`) using cobalt-strike [check my cobalt-wipe repo]
* place your shellcode inside [encoder.py](https://github.com/ORCA666/EVA/blob/main/encoder.py) and run it using python2
* after [encoder.py](https://github.com/ORCA666/EVA/blob/main/encoder.py) output your encrypted shellcode copy and paste it inside [EVA.cpp](https://github.com/ORCA666/EVA/blob/main/EVA/EVA.cpp)
* build the code using visual studio 2019 - Release - x64 `x86 wont work`
* enjoy


*************************************************************************************

# How Does EVA Work:
* first EVA will take a look at the running processes to allocate the pid of chrome.exe and inject the shellcode to it.
* if chrome.exe is not open, EVA will inject the code to explorer.exe instead

*************************************************************************************

# DEMO: 

### [+] You can do your self a favour and disable *Automatic Sample Submission* in windows defender:

![Screenshot 2021-06-25 123639](https://user-images.githubusercontent.com/66519611/123405199-4137c100-d5b2-11eb-9d34-a2ae0ca65045.png)

*************************************************************************************


## 1- explorer - injection:

https://user-images.githubusercontent.com/66519611/123220470-ac13ca00-d4d6-11eb-8a88-fdab5306d5d7.mp4


## 2- chrome - injection:

https://user-images.githubusercontent.com/66519611/123220562-c0f05d80-d4d6-11eb-8b6e-657236dd43e1.mp4


*************************************************************************************

# special thanks for:
* [hasherezade](https://github.com/hasherezade) - for helping me in building EVA inside visual studio
* and for the person who posted the decoding way in memory, i forgot where i got it from : | if you are seeing this please reply !


*************************************************************************************

### please feel free to post any issue or any suggestions

### i will be adding more information about how does it work `nah i wont, however if you want to know more about the code email me :>`

*************************************************************************************


### [MIT LICENSE ](https://github.com/ORCA666/EVA/blob/main/LICENSE)

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*************************************************************************************

# My Empty Ethereum Wallet : 0x1B4944030818392D76672f583884F4A125A4415e
![120064592-a5c83480-c075-11eb-89c1-78732ecaf8d3](https://user-images.githubusercontent.com/66519611/123219351-791d0680-d4d5-11eb-8248-e34069d0ad6d.png)



