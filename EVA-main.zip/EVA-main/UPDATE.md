# since an asshole uploaded the exe fie to virus total (the same day i uploaded it):

![Screenshot 2021-06-25 122158](https://user-images.githubusercontent.com/66519611/123402000-fae16280-d5af-11eb-91b3-d0290fc07ba9.png)

*************************************************************************************************************************

# this happened (today):

![cmeDaHsXkR9q](https://user-images.githubusercontent.com/66519611/123402113-12205000-d5b0-11eb-943c-dfbaca7f1a83.png)

*************************************************************************************************************************

# for the people that dont know, u can know if someone uploaded an file to virus total by searching for it, using the hash
### for EVA.exe in this project the md5 hash is: 5a3fec075d1999433c3146e1f1928817
### u can go to [here](https://www.virustotal.com/gui/home/search) and paste the md5 hash.

*************************************************************************************************************************

# for the one who did that, i dont give a fuck, but your useless dumb bitch



# UPDATE [FRIDAY JULY 2]: IM BACK, WORKING ON NEW VERSION THAT WONT EVEN CONTAIN THE SHELLCODE :) SO FUCK VIRUSTOTAL

*************************************************************************************************************************

# ORCA666
### _EVERYWHERE_
