#!/usr/bin/python
#coded by orca666

import sys


xor_key_list = [0x74]

def xor(data, key):

	return bytes(bytearray((
	    (data[i] ^ key for i in range(0,len(data))
	))))
    

with open("payload.bin", "rb") as shellcodeFileHandle:
    shellcodeBytes = bytearray(shellcodeFileHandle.read())
transformedShellcode = shellcodeBytes


for each_key in xor_key_list:
    transformedShellcode = xor(transformedShellcode, each_key)

with open("result.bin", "wb") as shellcodeFileHandle:
    shellcodeFileHandle.write(transformedShellcode)
    
