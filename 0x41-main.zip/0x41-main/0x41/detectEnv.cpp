#include <windows.h>
#include <iostream>
#include <TlHelp32.h>
#include <wlanapi.h>
#include <wininet.h>

#pragma comment(lib, "wlanapi.lib")
#pragma comment (lib, "Wininet.lib")

#include "connector.h"
#include "ntddk.h"
#include "connector.h"


using namespace std;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


DWORD GetParentPID(DWORD pid)
{
	DWORD ppid = 0;
	PROCESSENTRY32W processEntry = { 0 };
	processEntry.dwSize = sizeof(PROCESSENTRY32W);
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if (Process32FirstW(hSnapshot, &processEntry))
	{
		do
		{
			if (processEntry.th32ProcessID == pid) {
				ppid = processEntry.th32ParentProcessID;
				break;
			}
		} while (Process32NextW(hSnapshot, &processEntry));
	}
	CloseHandle(hSnapshot);
	printf("[+] parent pid : %d \n", ppid);
	return ppid;
}


DWORD GET_TARG_PROC(char* TargetProc) {
	ULONG retLen = 0;
	NtQuerySystemInformation(SystemProcessInformation, 0, 0, &retLen);
	if (retLen == 0) {
		return false;
	}
	const size_t bufLen = retLen;
	void* infoBuf = malloc(bufLen);
	if (!infoBuf) {
		return false;
	}
	memset(infoBuf, 0, bufLen);
	SYSTEM_PROCESS_INFORMATION* sys_info = (SYSTEM_PROCESS_INFORMATION*)infoBuf;
	if (NtQuerySystemInformation(SystemProcessInformation, sys_info, bufLen, &retLen) == STATUS_SUCCESS) {
		while (true) {
			char Process[70];
			int pid = (int)sys_info->UniqueProcessId;
			if (sys_info->ImageName.Buffer) {
				wcstombs(Process, sys_info->ImageName.Buffer, 70);
				if (strcmp(TargetProc, Process) == 0) {
					return pid;
				}
			}
			if (!sys_info->NextEntryOffset) {
				break;
			}
			sys_info = (SYSTEM_PROCESS_INFORMATION*)((ULONG_PTR)sys_info + sys_info->NextEntryOffset);
		}
	}
	free(infoBuf);
	return -1;
}

int find_Explorer() {
	char* processName = (char*)"explorer.exe";
	DWORD processID = GET_TARG_PROC(processName);
	return processID;
}

int detect_parent() {
	DWORD parentPid = GetParentPID(GetCurrentProcessId());
	printf("[+] Targetting Pid : %d \n", GetCurrentProcessId());
	printf("[+] Explorer.exe pid is %d \n", find_Explorer());
	if (find_Explorer() != parentPid) {
		printf("[!] DANGEROUS ===> Explorer.exe is [NOT] our PPID ...\n");
		return -1;
	}
	else if (find_Explorer() == parentPid) {
		printf("[+] NORMAL ===> Explorer.exe is our PPID... \n");
		return 1;
	}
	else {
		printf("[!] DANGEROUS ===> Something unusual happend ...\n");
		return -1;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////



VOID WlanNotification(WLAN_NOTIFICATION_DATA* wlanNotifData, VOID* p)
{
	if (wlanNotifData->NotificationCode == wlan_notification_acm_scan_complete)
	{
		bool bWait = false;
	}
	else if (wlanNotifData->NotificationCode == wlan_notification_acm_scan_fail)
	{
		bool bWait = false;
	}
}


bool DETECT_WIFI() {

	HANDLE hWlan = NULL;

	DWORD dwError = 0;
	DWORD dwSupportedVersion = 0;
	DWORD dwClientVersion = (TRUE ? 2 : 1);

	GUID guidInterface; ZeroMemory(&guidInterface, sizeof(GUID));

	WLAN_INTERFACE_INFO_LIST* wlanInterfaceList = (WLAN_INTERFACE_INFO_LIST*)WlanAllocateMemory(sizeof(WLAN_INTERFACE_INFO_LIST));
	ZeroMemory(wlanInterfaceList, sizeof(WLAN_INTERFACE_INFO_LIST));

	WLAN_AVAILABLE_NETWORK_LIST* wlanNetworkList = (WLAN_AVAILABLE_NETWORK_LIST*)WlanAllocateMemory(sizeof(WLAN_AVAILABLE_NETWORK_LIST));
	ZeroMemory(wlanNetworkList, sizeof(WLAN_AVAILABLE_NETWORK_LIST));

	int xxx = 0;

	try
	{
		if (dwError = WlanOpenHandle(dwClientVersion, NULL, &dwSupportedVersion, &hWlan) != ERROR_SUCCESS)
			return FALSE;

		if (dwError = WlanEnumInterfaces(hWlan, NULL, &wlanInterfaceList) != ERROR_SUCCESS)
			return FALSE;

		if (dwError = wlanInterfaceList->InterfaceInfo[0].isState != wlan_interface_state_not_ready)
		{
			if (wlanInterfaceList->dwNumberOfItems > 1)
			{
				guidInterface = wlanInterfaceList->InterfaceInfo[0].InterfaceGuid;
			}
			else
			{
				guidInterface = wlanInterfaceList->InterfaceInfo[0].InterfaceGuid;
			}
		}
		else
			return FALSE;

		DWORD dwPrevNotif = 0;
		bool bWait = true;


		if (dwError = WlanRegisterNotification(hWlan, WLAN_NOTIFICATION_SOURCE_ACM, TRUE,
			(WLAN_NOTIFICATION_CALLBACK)WlanNotification, NULL, NULL, &dwPrevNotif) != ERROR_SUCCESS)
			return FALSE;

		if (dwError = WlanScan(hWlan, &guidInterface, NULL, NULL, NULL) != ERROR_SUCCESS)
			return FALSE;


		WlanRegisterNotification(hWlan, WLAN_NOTIFICATION_SOURCE_NONE, TRUE, NULL, NULL, NULL, &dwPrevNotif);

		if (dwError = WlanGetAvailableNetworkList(hWlan, &guidInterface, NULL, NULL, &wlanNetworkList) != ERROR_SUCCESS)
			return FALSE;

		for (unsigned int i = 0; i < wlanNetworkList->dwNumberOfItems; i++)
		{
			xxx++;
		}
	}
	catch (char* szError)
	{
		printf("[!] Sandbox detected\n");
		return FALSE;
	}

	if (wlanNetworkList)
		WlanFreeMemory(wlanNetworkList);
	if (wlanInterfaceList)
		WlanFreeMemory(wlanInterfaceList);
	if (hWlan)
		WlanCloseHandle(hWlan, NULL);

	if (xxx > 0)
		return TRUE;

}

int DetectSandbox() {
	if (DETECT_WIFI() == FALSE) {
		return -1;
	}
}