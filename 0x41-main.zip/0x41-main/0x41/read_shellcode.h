#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <Windows.h>

//#ifdef _DEBUG
#define DOUT(x) do { std::cout <<x; } while(0)
//#else 
//#define DOUT(x) do { ; } while(0)
//#endif

#define KEY	0x74	/* The key should be same as used when encoding */

// Reads a XOR encoded binary shellcode file.
// XOR key is macro defined in this file
std::vector<unsigned char> read_shellcode(const char* in_file) {
	std::vector <unsigned char> shellcode;

	DOUT("[+] Trying to open shellcode file....");
	std::ifstream fin(in_file, std::ios::binary);
	if (fin) { // Read file only if we have been able to open it successfully
		DOUT("[SUCCESS]\n");
		while (1) {

			int ch = fin.get();
			if (ch == EOF)
				break;

			// XOR the byte read with the Key
			ch ^= KEY;
			shellcode.push_back(ch);
		}
	}
	else {
		DOUT("[FAILED]\n");
	}
	fin.close();
	if (shellcode.size() != 0)
		DOUT("[+] Read shellcode size = " << shellcode.size() << " bytes\n");
	else
		DOUT("[-] Could not read shellcode\n");

	return shellcode;
}