#pragma once
#include <vector>

/**
* Base class for any loader to be designed. This provides a pure virtual function which
* will be implemented by a Loader type. This makes implementation of other loaders easy
* Only Class pertaining to other loaders need to be added.
*/

class Loader
{
protected:
	std::vector <unsigned char> shellcode;
public:
	// Only parameterised constructor. Ensures that parameter is provided
	Loader(std::vector<unsigned char> shellcode) {
		this->shellcode = shellcode;
	}

	~Loader() {
		shellcode.clear();
	}

	virtual void load_shellcode() = 0;	// Pure virtual function to load shellcode
};

