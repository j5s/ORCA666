#ifndef CONNECTOR_H	
#define CONNECTOR_H

#ifdef __cplusplus
extern "C" {
#endif

	int detect_parent();
	int DetectSandbox();

#ifdef __cplusplus

}
#endif // __cplusplus

#endif // CONNECTOR_H	