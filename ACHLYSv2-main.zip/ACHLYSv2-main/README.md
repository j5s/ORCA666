# ACHLYSv2

# How it works: 

1. First ACHLYS detects the environment of the machine its being in, by checking sandboxes and debuggers presents.

2. second when the check succeeded achlys will download a pdf file (u created by a python script that comes with it)
   the pdf file is the payload, the reason why its a pdf file is that some avs won't even upload to there servers for analysis,
   thats bcz it assume its personal information - review kaspersky av for example -

3. then it will start to inject the pdf file into the memory 5 bytes at a time, and not all the shellcodes at once, it will sleep for 1 sec
   after each 5 bytes are injected.

4. After the injection succeeds it will sleep again for 10 secs before executing the shellcode.

5. Achlysv2 injects the payload to other processes with the help of 2 apis:
 - `DebugActiveProcess`
 - `DebugActiveProcessStop`

6. in addition to that achlys uses sysalls obtained by hashes during [runtime], Using Hellsgate Way.



# USAGE :

1. first load the profile using the following command: ./teamserver.sh <ur ip address> <ur password> <path to the profile file> .

2. run cobalt strike : ./cobaltstrike.sh .

3. generate ur payload [preferably https] 'but its a must to create it as x64 [c file format]'
   Attacks -> Packages -> Payload Generator .

4. after generating the profile remove the [""] and the [;] and any other thing that is not the actual shellcode ... 
   at the end it should look like [shellcode.txt] file that comes with ACHLYS .

5. after u have ur clean shellcode, run the python script to make it a pdf file :
   python3 sc2pdf.py <ur clean shellcode file that is generated in step 4> <the output name of the pdf>
   Ex: python3 sc2pdf.py shellcode.txt file.pdf

6. now we have shellcode file that is in pdf file format, upload it to a website that allows direct download, and copy the link of the download option.
   Ex: 'raw' / 'download' options in github / gitlab

7. paste ur copied url [from step 6] to line [350](https://github.com/ORCA666/ACHLYSv2/blob/725223928d26e579c03dc7807a7c7cacf62126c4/ACHLYS%202/DripLoader/functions.cpp#L350) in file [functions.cpp]
   Like so : L"ur url goes here",

8. build the project as [x64] [Release]   --- Note: it wont work if u compiled it as x86 ---

9. enjoy !


