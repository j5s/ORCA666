#ifndef CONNECTOR_H	
#define CONNECTOR_H

unsigned char* ReadPDFFILE(const char* fnamSc, DWORD* szSc);
int FIND_TARGET_INJECTION_PID();

#endif 