//coded by orca666

#ifndef CONNECTOR_H	
#define CONNECTOR_H

#ifdef __cplusplus
extern "C" {
#endif

	int find();


#ifdef __cplusplus

}
#endif // __cplusplus

#endif // CONNECTOR_H	
