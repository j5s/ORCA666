#!/bin/python3

import sys
import re

N = 5  # Number of bytes to split 
if len(sys.argv) != 3:
    print("Usage %s <in-shellcode-string> <out-pdf>" % (__file__,))
    sys.exit(-1)

f1 = [_.strip('"') for _ in open(sys.argv[1],"r").readlines()]
f2 = ''.join(f1)

if re.search(r"\\x[0-9a-fA-F][\\\s]",f2) != None:
    print("[!] Ill formed shellcode string. Contains illegal hex e.g \\xf instead of \\x0f")
    sys.exit(-1)

with open(sys.argv[2],"wb") as pdf:
    for i in range(0,len(f2),4*N):
        pdf.write(f2[i:i+4*N].encode())
        pdf.write(b'\n')

print ("[+] Wrote to %s" % (sys.argv[2]))



