#ifndef CONNECTOR_H	
#define CONNECTOR_H

unsigned char* ReadPDFFILE(const char* fnamSc, DWORD* szSc);

#endif 