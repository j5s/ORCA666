#pragma once
#include <Windows.h>

#define STATUS_SUCCESS 0
 


EXTERN_C NTSTATUS NtWriteVirtualMemory(
	HANDLE hProcess,
	PVOID lpBaseAddress,
	PVOID lpBuffer,
	SIZE_T NumberOfBytesToWrite,
    PSIZE_T NumberOfBytesWritten
);


