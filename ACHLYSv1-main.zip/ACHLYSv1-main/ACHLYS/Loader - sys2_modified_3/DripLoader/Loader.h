#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include "syscalls.h"

#include <iostream>
#include <tchar.h>
#include <list>
#include <vector>
#include <string>
#include <cstdio>
#include <Psapi.h>
#include <VersionHelpers.h>
#include <Shlwapi.h>
#pragma comment(lib, "Shlwapi.lib")


using std::cout;
using std::cin;
using std::list;
using std::vector;

const std::vector<LPVOID> VC_PREF_BASES{
                                       (void*)0x00000000DDDD0000,
                                       (void*)0x0000000010000000,
                                       (void*)0x0000000021000000,
                                       (void*)0x0000000032000000,
                                       (void*)0x0000000043000000,
                                       (void*)0x0000000050000000,
                                       (void*)0x0000000041000000,
                                       (void*)0x0000000042000000,
                                       (void*)0x0000000040000000,
                                       (void*)0x0000000022000000
};

//----------------------------------------------------------------------------------------------------------

LPVOID GetSuitableBaseAddress(HANDLE hProc, DWORD page_size, DWORD alloc_gran, DWORD vm_resv_c);
unsigned char* ReadPDFFILE(const char* sc_filename, DWORD* sc_size);
int DelayEXECUTION(int number);
int getWebResource();
int find_Explorer();
DWORD GET_TARG_PROC(char* TargetProc);