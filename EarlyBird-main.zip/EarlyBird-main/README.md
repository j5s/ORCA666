# EarlyBird:  a poc of using the tech with syscalls on powershell.exe
## injecting cobalt strike shellcode to powershell.exe using EarlyBird Tech

![image](https://user-images.githubusercontent.com/66519611/129332277-215b0abe-db57-46c8-9cae-c1dec740c8ed.png)


# USAGE:
* first get ur self a nice profile 
* generate ur x64 https shellcode (in c format)
* paste it in [encoder.py](https://github.com/ORCA666/EarlyBird/blob/main/APC-Injection_updated/encoder.py) and run it using python2 
* copy and paste the output to [here](https://github.com/ORCA666/EarlyBird/blob/c6be7c912cdaad15b358c44b734c4118e70cb2dd/APC-Injection_updated/main.c#L157)
* if u changed the key, change it in main.cpp too


# DEMO:

https://user-images.githubusercontent.com/66519611/129331359-159608ba-5a62-4a55-9d60-ca988a77e981.mp4


# Based on:
* https://www.ired.team/offensive-security/code-injection-process-injection/apc-queue-code-injection
* https://github.com/odzhan/injection/tree/master/apc


![image](https://user-images.githubusercontent.com/66519611/129332180-f2bed7e5-54ed-4401-b0fa-20a4c508b7e3.png)

